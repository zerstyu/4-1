package com.example.exampleapplication;

import java.net.*;
import java.io.*;
import java.util.Scanner;

import android.util.Log;

public class TcpIpMultichatClient {
	String name;
	String module;
	public TcpIpMultichatClient(String name) {
		this.name = name;
		module = "";
	}
	
	public TcpIpMultichatClient(String deviceId, String module) {
		this.name = deviceId;
		this.module = module;
	}

	public void start() {
		try {
			String serverIp = "127.0.0.1";
			// ������ �����Ͽ� ������ ��û�Ѵ�.
			Socket socket = new Socket(serverIp, 7777);
			System.out.println("������ ����Ǿ����ϴ�.");

			Thread sender = new Thread(new ClientSender(socket, name, module));
			//Thread receiver = new Thread(new ClientReceiver(socket));

			sender.start();
			//receiver.start();
		} catch (ConnectException ce) {
			Log.e("connection", ce.toString());
		} catch (Exception e) {
			
			Log.e("connection", e.toString());
		}
	} // main

	static class ClientSender extends Thread {
		Socket socket;
		DataOutputStream out;
		String name;
		String module;
		
		ClientSender(Socket socket, String name) {
			this.socket = socket;
			try {
				out = new DataOutputStream(socket.getOutputStream());
				this.name = name;
			} catch (Exception e) {
			}
		}

		public ClientSender(Socket socket2, String name2, String module) {
			// TODO Auto-generated constructor stub
			this.socket = socket2;
			try {
				out = new DataOutputStream(socket.getOutputStream());
				this.name = name2;
				this.module = module;
			} catch (Exception e) {
			}
		}

		public void run() {
			try {
				if (out != null) {
					if(module.equals("")) {
						out.writeUTF(name);
					}else {
						out.writeUTF(name + "|" + module );
					}
				}
				
				
				socket.close();
				/*
				while (out != null) {
					out.writeUTF("[" + name + "]" + scanner.nextLine());
				}*/
			} catch (IOException e) {
				System.out.println("�����߻�");
			}
		} // run()
	}

	static class ClientReceiver extends Thread {
		Socket socket;
		DataInputStream in;

		ClientReceiver(Socket socket) {
			this.socket = socket;
			try {
				in = new DataInputStream(socket.getInputStream());
			} catch (IOException e) {
			}
		}

		public void run() {
			while (in != null) {
				try {
					System.out.println(in.readUTF());
				} catch (IOException e) {
				}
			}
		} // run
	}
} // class
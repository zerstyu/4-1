package com.example.exampleapplication;

import java.util.UUID;

import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class Example extends Activity implements OnClickListener {
	Button sendmsg;
	Button sendid;
	Toast toast;
	TelephonyManager tm;
	String tmDevice, tmSerial, androidId;
	UUID deviceUuid;
	String deviceId;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_example);

		sendmsg = (Button) findViewById(R.id.sendmsg);
		sendid = (Button) findViewById(R.id.sendid);
		
		
		sendmsg.setOnClickListener(this);
		sendid.setOnClickListener(this);
		
		
		// application name
		tm = (TelephonyManager) getBaseContext().getSystemService(
				Context.TELEPHONY_SERVICE);

		tmDevice = "" + tm.getDeviceId();
		tmSerial = "" + tm.getSimSerialNumber();
		androidId = ""
				+ android.provider.Settings.Secure.getString(
						getContentResolver(),
						android.provider.Settings.Secure.ANDROID_ID);

		deviceUuid = new UUID(androidId.hashCode(),
				((long) tmDevice.hashCode() << 32) | tmSerial.hashCode());
		deviceId = deviceUuid.toString();
		// transmit name & module
		new TcpIpMultichatClient(deviceId, "cam|gps|leftbus").start();

		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
				.detectDiskReads().detectDiskWrites().detectNetwork()
				.penaltyLog().build());

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.example, menu);
		return true;
	}

	@Override
	public void onClick(View view) {
		// TODO Auto-generated method stub
		switch (view.getId()) {
		case R.id.sendmsg:
			toast.makeText(this, "ID Module ����", Toast.LENGTH_LONG).show();
			new TcpIpMultichatClient(deviceId, "cam|gps|leftbus").start();
			break;
		case R.id.sendid:
			toast.makeText(this, "ID ����", Toast.LENGTH_LONG).show();

			new TcpIpMultichatClient(deviceId).start();
			break;
			
			
		default:
			toast.makeText(this, "���� ��", Toast.LENGTH_LONG).show();
		}
	}

	public boolean onKeyDown(int KeyCode, KeyEvent event) {
		if (KeyCode == KeyEvent.KEYCODE_BACK) {
			new AlertDialog.Builder(this)
					.setIcon(android.R.drawable.ic_dialog_alert)
					.setMessage("Do you close your Example application ?")
					.setPositiveButton("Yes",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									finish();
								}
							}).setNegativeButton("No", null).show();
			return true;
		}
		return super.onKeyDown(KeyCode, event);
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		new TcpIpMultichatClient(deviceId).start();
	}

}

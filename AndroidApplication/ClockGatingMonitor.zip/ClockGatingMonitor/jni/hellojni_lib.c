#include "com_example_clockgatingmonitor_NativeCall.h"
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <sys/mman.h>

static int fd;  // file pointer

JNIEXPORT jstring JNICALL Java_com_example_clockgatingmonitor_NativeCall_PrintFromJNI(
		JNIEnv * env, jobject obj) {
	jint dev;
	if ((dev = open("/dev/EXYNOS4210_ClockGatingDrv", O_RDWR, 777) < 0)) {
		return (*env)->NewStringUTF(env,
				" EXYNOS4210_ClockGatingDrv Open Failed! ");
	}

	return (*env)->NewStringUTF(env,
			" EXYNOS4210_ClockGatingDrv Open Sucessed! ");
}
JNIEXPORT jint JNICALL Java_com_example_clockgatingmonitor_NativeCall_Check(
		JNIEnv * env, jobject obj, jint a) {

	int fdCGDrv, ret;

	fdCGDrv = open("/dev/EXYNOS4210_ClockGatingDrv", O_RDWR & !O_EXCL);
	if (fdCGDrv < 0) {
		return errno;
	}
	ioctl(fdCGDrv, 0);
}
JNIEXPORT jint JNICALL Java_com_example_clockgatingmonitor_NativeCall_Add(
		JNIEnv * env, jobject obj, jint a, jint b) {

	int fdCGDrv, ret;

	fdCGDrv = open("/dev/EXYNOS4210_ClockGatingDrv", O_RDWR & !O_EXCL);
	if (fdCGDrv < 0) {
		return errno;
	}
	switch (a) {
	case 0:
		if (b == 0)
			ioctl(fdCGDrv, 0x04800, 0x00000000);
		else
			ioctl(fdCGDrv, 0x04800, 0xFFFFFFFF);
		break;
	case 1:
		if (b == 0)
			ioctl(fdCGDrv, 0x08800, 0x00000000);
		else
			ioctl(fdCGDrv, 0x08800, 0xFFFFFFFF);
		break;
	case 2:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C920, b);
		else
			ioctl(fdCGDrv, 0x0C920, 0xFFFFFFFF);
		break;
	case 3:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C924, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C924, 0xFFFFFFFF);
		break;
	case 4:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C928, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C928, 0xFFFFFFFF);
		break;
	case 5:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C92C, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C92C, 0xFFFFFFFF);
		break;
	case 6:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C930, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C930, 0xFFFFFFFF);
		break;
	case 7:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C934, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C934, 0xFFFFFFFF);
		break;
	case 8:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C938, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C938, 0xFFFFFFFF);
		break;
	case 9:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C940, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C940, 0xFFFFFFFF);
		break;
	case 10:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C94C, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C94C, 0xFFFFFFFF);
		break;
	case 11:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C950, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C950, 0xFFFFFFFF);
		break;
	case 12:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C960, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C960, 0xFFFFFFFF);
		break;
	case 13:
		if (b == 0)
			ioctl(fdCGDrv, 0x10900, 0x00000000);
		else
			ioctl(fdCGDrv, 0x10900, 0xFFFFFFFF);
		break;
	case 14:
		if (b == 0)
			ioctl(fdCGDrv, 0x14900, 0x00000000);
		else
			ioctl(fdCGDrv, 0x14900, 0xFFFFFFFF);
		break;
	case 15:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C820, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C820, 0xFFFFFFFF);
		break;
	case 16:
		if (b == 0)
			ioctl(fdCGDrv, 0x14800, 0x00000000);
		else
			ioctl(fdCGDrv, 0x14800, 0xFFFFFFFF);
		break;
	case 17:
		if (b == 0)
			ioctl(fdCGDrv, 0x0C970, 0x00000000);
		else
			ioctl(fdCGDrv, 0x0C970, 0xFFFFFFFF);
		break;

	}

	return a;
}


package com.example.clockgatingmonitor;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.Toast;

public class BasicService extends Service {
	private boolean isRunning;
	class MyThread_Sock extends Thread {
		
		public void run() {
			
			new TcpIpMultichatServer().start();
			
		}
	}
	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if(msg.what == 0) {
				String str = (String)msg.obj;
				Toast.makeText(BasicService.this, str, Toast.LENGTH_LONG).show();
			}
		}
	};
	
	@Override
	public void onCreate() {
		super.onCreate();
	}
	
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		super.onStartCommand(intent, flags, startId);
		
		isRunning = false;
		MyThread_Sock th2 = new MyThread_Sock();
		th2.start();
		
		return Service.START_STICKY;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		Toast.makeText(this, "���񽺸� ����", Toast.LENGTH_LONG).show();
		isRunning = true;
	}
}
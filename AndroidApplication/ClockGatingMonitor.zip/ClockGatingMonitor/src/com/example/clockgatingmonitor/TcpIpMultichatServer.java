package com.example.clockgatingmonitor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.apache.http.HttpResponse;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

public class TcpIpMultichatServer {
	HashMap clients;
	Toast toast;
	ClockGating clockGating;
	RegisterManage clockRegister;
	HashMap<String, String> manageclients;

	NativeCall nativecall;

	TcpIpMultichatServer() {
		nativecall = new NativeCall();	
		manageclients = new HashMap<String, String>();
		nativecall = new NativeCall();
		clockRegister = new RegisterManage();
		clients = new HashMap();
		Collections.synchronizedMap(clients);
	}

	public void start() {

		ServerSocket serverSocket = null;
		Socket socket = null;
		int ret;
		// toast = new Toast(clockGating);

		try {
			serverSocket = new ServerSocket(7777);
			nativecall.Add(0, clockRegister.OFFCLOCK);		//LEFTBUS  ******
			nativecall.Add(2, clockRegister.OFFCLOCK);		//CAM      ******
			nativecall.Add(3, clockRegister.OFFCLOCK);		//TV
//			nativecall.Add(4, clockRegister.OFFCLOCK);		//MFC
			nativecall.Add(6, clockRegister.OFFCLOCK);		//IMAGE
//			nativecall.Add(8, clockRegister.OFFCLOCK);		//LCD1
//			nativecall.Add(9, clockRegister.OFFCLOCK);		//FSYS
			nativecall.Add(10, clockRegister.OFFCLOCK);		//GPS      ******
			nativecall.Add(14, clockRegister.OFFCLOCK);		//CPU
			ret = nativecall.Check(0);			
			while (true) {
				// client ���� ��ٸ�
				socket = serverSocket.accept();

				// client ����
				Log.e("e", "������ ����Ǿ����ϴ�.");
				Log.e("e",
						"[" + socket.getInetAddress() + ":" + socket.getPort()
								+ "]" + "���� �����Ͽ����ϴ�.");
				// System.out.println("[" + socket.getInetAddress() + ":"+
				// socket.getPort() + "]" + "���� �����Ͽ����ϴ�.");
				ServerReceiver thread = new ServerReceiver(socket);
				thread.start();

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	} // start()

	void sendToAll(String msg) {
		Iterator it = clients.keySet().iterator();

		while (it.hasNext()) {
			try {
				DataOutputStream out = (DataOutputStream) clients
						.get(it.next());
				out.writeUTF(msg);
			} catch (IOException e) {
			}
		} // while
	} // sendToAll

	// //////////////////////////////////////////

	class ServerReceiver extends Thread {
		Socket socket;
		DataInputStream in;
		DataOutputStream out;
		String[] temp;
		int ret;
		
		public ServerReceiver(Socket socket) {
			this.socket = socket;
			try {
				in = new DataInputStream(socket.getInputStream());
				out = new DataOutputStream(socket.getOutputStream());
			} catch (IOException e) {
			}
		}

		public void run() {
			String receiveMsg = "";
			try {
				// ///////////////////////////////////////////////////////////////////////////////
				// ///////////////////////////////////////////////////////////////////////////////
				//nativecall = new NativeCall();
				receiveMsg = in.readUTF();

				if (receiveMsg.length() >= 38) {
					clients.put(receiveMsg, out);

					// �̸� �� ��� ������
					temp = receiveMsg.split("\\|");

					// ��⸶�� ����̽� ����̹�     int  ����
					for (int i = 1; i < temp.length; i++) {
						if (temp[i].equals("leftbus")) {
							clockRegister.register[0] ++;
							ret = nativecall.Add(0, clockRegister.ONCLOCK);
							System.out.println("-----leftbus-----" + clockRegister.IP_LEFTBUS);
						}
						if (temp[i].equals("rightbus")) {
							clockRegister.register[1] ++;
							ret = nativecall.Add(1, clockRegister.ONCLOCK);
						}
						if (temp[i].equals("cam")) {
							clockRegister.register[2] ++;
							ret = nativecall.Add(2, clockRegister.ONCLOCK);
							System.out.println("-----cam-----" + clockRegister.IP_CAM);
						}
						if(temp[i].equals("tv")) {
							clockRegister.register[3] ++;
							ret = nativecall.Add(3, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("mfc")) {
							clockRegister.register[4] ++;
							ret = nativecall.Add(4, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("g3d")) {
							clockRegister.register[5] ++;
							ret = nativecall.Add(5, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("image")) {
							clockRegister.register[6] ++;
							ret = nativecall.Add(6, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("lcd0")) {
							clockRegister.register[7] ++;
							ret = nativecall.Add(7, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("lcd1")) {
							clockRegister.register[8] ++;
							ret = nativecall.Add(8, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("fsys")) {
							clockRegister.register[9] ++;
							ret = nativecall.Add(9, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("gps")) {
							clockRegister.register[10] ++;
//							ret = nativecall.Add(clockRegister.IP_GPS, clockRegister.ONCLOCK);
							ret = nativecall.Add(10, clockRegister.ONCLOCK);
							System.out.println("-----gps-----" + clockRegister.IP_GPS);
						}
						if(temp[i].equals("peril")) {
							clockRegister.register[11] ++;
							ret = nativecall.Add(11, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("perir")) {
							clockRegister.register[12] ++;
							ret = nativecall.Add(12, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("dmc")) {
							clockRegister.register[13] ++;
							ret = nativecall.Add(13, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("cpu")) {
							clockRegister.register[14] ++;
//							ret = nativecall.Add(clockRegister.IP_CPU, clockRegister.ONCLOCK);
							ret = nativecall.Add(14, clockRegister.ONCLOCK);
							System.out.println("-----cpu-----" + clockRegister.IP_CPU);
						}
						if(temp[i].equals("sclkcam")) {
							clockRegister.register[15] ++;
							ret = nativecall.Add(15, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("sclkcpu")) {
							clockRegister.register[16] ++;
							ret = nativecall.Add(16, clockRegister.ONCLOCK);
						}
						if(temp[i].equals("block")) {
							clockRegister.register[17] ++;
							ret = nativecall.Add(17, clockRegister.ONCLOCK);
						}
											
//						ret = nativecall.Add(50, 60);
//						if (ret < 0) {
//							System.out
//									.println(" EXYNOS4210_ClockGatingDrv Open Failed! Faile Num = " + ret);
//						} else {
//							System.out.println(" EXYNOS4210_ClockGatingDrv Open Successed! Success Num = " + ret);
//						}

					}

					// ��⸸ �ٽ� ��ü
					String module = "";
					for (int i = 1; i < temp.length; i++) {
						module += temp[i] + "|";
					}
					System.out.println(temp[0] + " --- " + module);

					manageclients.put(temp[0], module);

					// String mapModule = manageclients.get(temp[0]);
					//
					// // Hash���� ���
					// System.out.println(mapModule);
					// temp = mapModule.split("\\|");
					// for (int i = 0; i < temp.length; i++) {
					// System.out.println(temp[i]);
					// }

					// ����̽� ����̹� ����

				} else {
					receiveMsg.split("\\|");
					System.out.println(receiveMsg);
					String mapModule = manageclients.get(receiveMsg);
					manageclients.remove(receiveMsg);
					// Hash���� ���
					System.out.println(mapModule);
					temp = mapModule.split("\\|");

					// �� ��⸶�� ����̽� ����̹� ����
					for (int i = 0; i < temp.length; i++) {
						if (temp[i].equals("leftbus")) {
							clockRegister.register[0] --;
							if(clockRegister.register[0] < 1)
								ret = nativecall.Add(0, clockRegister.OFFCLOCK);
							System.out.println("-----leftbus-----" + clockRegister.IP_LEFTBUS);
						}
						if (temp[i].equals("rightbus")) {
							clockRegister.register[1] --;
							if(clockRegister.register[1] < 1)
								ret = nativecall.Add(1, clockRegister.OFFCLOCK);
						}
						if (temp[i].equals("cam")) {
							clockRegister.register[2] --;
							if(clockRegister.register[2] < 1)
								ret = nativecall.Add(2, clockRegister.OFFCLOCK);
							System.out.println("-----cam-----" + clockRegister.IP_CAM);
						}
						if(temp[i].equals("tv")) {
							clockRegister.register[3] --;
							if(clockRegister.register[3] < 1)
								ret = nativecall.Add(3, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("mfc")) {
							clockRegister.register[4] --;
							if(clockRegister.register[4] < 1)
								ret = nativecall.Add(4, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("g3d")) {
							clockRegister.register[5] --;
							if(clockRegister.register[5] < 1)
								ret = nativecall.Add(5, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("image")) {
							clockRegister.register[6] --;
							if(clockRegister.register[6] < 1)
								ret = nativecall.Add(6, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("lcd0")) {
							clockRegister.register[7] --;
							if(clockRegister.register[7] < 1)
								ret = nativecall.Add(7, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("lcd1")) {
							clockRegister.register[8] --;
							if(clockRegister.register[8] < 1)
								ret = nativecall.Add(8, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("fsys")) {
							clockRegister.register[9] --;
							if(clockRegister.register[9] < 1)
								ret = nativecall.Add(9, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("gps")) {
							clockRegister.register[10] --;
							if(clockRegister.register[10] < 1)
								ret = nativecall.Add(10, clockRegister.OFFCLOCK);
							System.out.println("-----gps-----" + clockRegister.IP_GPS);
						}
						if(temp[i].equals("peril")) {
							clockRegister.register[11] --;
							if(clockRegister.register[11] < 1)
								ret = nativecall.Add(11, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("perir")) {
							clockRegister.register[12] --;
							if(clockRegister.register[12] < 1)
								ret = nativecall.Add(12, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("dmc")) {
							clockRegister.register[13] --;
							if(clockRegister.register[13] < 1)
								ret = nativecall.Add(13, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("cpu")) {
							clockRegister.register[14] --;
							if(clockRegister.register[14] < 1)
								ret = nativecall.Add(14, clockRegister.OFFCLOCK);
							System.out.println("-----cpu-----" + clockRegister.IP_CPU);
						}
						if(temp[i].equals("sclkcam")) {
							clockRegister.register[15] --;
							if(clockRegister.register[15] < 1)
								ret = nativecall.Add(15, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("sclkcpu")) {
							clockRegister.register[16] --;
							if(clockRegister.register[16] < 1)
								ret = nativecall.Add(16, clockRegister.OFFCLOCK);
						}
						if(temp[i].equals("block")) {
							clockRegister.register[17] --;
							if(clockRegister.register[17] < 1)
								ret = nativecall.Add(17, clockRegister.OFFCLOCK);
						}


//						ret = nativecall.Add(50, 60);

						// check open Device Driver
//						if (ret < 0) {
//							System.out
//									.println(" EXYNOS4210_ClockGatingDrv Open Failed! Faile Num = " + ret);
//						} else {
//							System.out.println(" EXYNOS4210_ClockGatingDrv Open Successed! Success Num = " + ret);
//						}
//
//						if (ret < 0) {
//							System.out
//									.println(" EXYNOS4210_ClockGatingDrv Open Failed! Faile Num = "
//											+ ret);
//						} else {
//							System.out
//									.println(" EXYNOS4210_ClockGatingDrv Open Successed! Success Num = "
//											+ ret);
//						}
					}
				}				
				ret = nativecall.Check(0);
			} catch (IOException e) {
				System.out.println("���� ����");
				// ignore
			} finally {
				// sendToAll("#" + name + "���� �����̽��ϴ�.");
				clients.remove(receiveMsg);
				System.out.println("[" + socket.getInetAddress() + ":"
						+ socket.getPort() + "]" + "���� ������ �����Ͽ����ϴ�.");
				System.out.println("���� ���������� ���� " + clients.size() + "�Դϴ�.");
			} // try
		} // run
	} // ReceiverThreadChawoghdww

} // cls
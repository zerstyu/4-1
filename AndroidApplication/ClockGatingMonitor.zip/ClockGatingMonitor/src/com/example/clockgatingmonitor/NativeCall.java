package com.example.clockgatingmonitor;

public class NativeCall {
	static {
		System.loadLibrary("hellojni_lib");
	}
	public native String PrintFromJNI();
	public native int Add(int a, int b);
	public native int Check(int a);
}

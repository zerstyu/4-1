package com.example.clockgatingmonitor;

import java.net.Socket;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ClockGating extends Activity implements OnClickListener {
	Socket socket;
	private Button sockOpen;
	private Button sockClose;

	private Button startbtn;
	private Button stopbtn;
	Toast toast;
	int Server_Port = 5292;	
	
	private Button bv;
	private TextView tv;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_clock_gating);

		bv = (Button) findViewById(R.id.callbtn);
		tv = (TextView) findViewById(R.id.rettxt);
		startbtn = (Button) findViewById(R.id.startbtn);
		stopbtn = (Button) findViewById(R.id.stopbtn);
		bv = (Button)findViewById(R.id.callbtn);
		tv = (TextView)findViewById(R.id.rettxt);
		
		toast = new Toast(this);
		
		
		
		startbtn.setOnClickListener(this);
		stopbtn.setOnClickListener(this);
		bv.setOnClickListener(this);
		
		
		
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectDiskReads().detectDiskWrites().detectNetwork().penaltyLog().build()); 
        
		startService(new Intent(this, BasicService.class));
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.clock_gating, menu);
		return true;
	}

	@Override
	public void onClick(View view) {
		switch(view.getId()) {
		case R.id.callbtn:
			NativeCall nativecall = new NativeCall();
			int ret = nativecall.Add(50, 60);
			if(ret < 0) {
				 tv.setText( " EXYNOS4210_ClockGatingDrv Open Failed! Faile Num = "+ ret);
			}
			else {
				tv.setText( " EXYNOS4210_ClockGatingDrv Open Successed! Success Num = "+ ret);
			}
			break;
			
		case R.id.startbtn:
			toast.makeText(this, "���� ����", Toast.LENGTH_LONG).show();
			startService(new Intent(this, BasicService.class));
			break;
			
		case R.id.stopbtn:
			stopService(new Intent(this, BasicService.class));
			break;
			
			
			
		default:
			tv.setText("���� ����");
		}		
	}
}

package com.example.clockgatingmonitor;

public class RegisterManage {
	int IP_LEFTBUS;
	int IP_RIGHTBUS;
	int IP_CAM;
	int IP_TV;
	int IP_MFC;
	int IP_G3D;
	int IP_IMAGE;
	int IP_LCD0;
	int IP_LCD1;
	int IP_FSYS;
	int IP_GPS;
	int IP_PERIL;
	int IP_PERIR;
	int IP_DMC;
	int IP_CPU;
	int SCLKCAM;
	int SCLKCPU;
	int BLOCK;
	int ONCLOCK;
	int OFFCLOCK;
	int register[];
	
	public RegisterManage() {
		IP_LEFTBUS = 0x4800;
		IP_RIGHTBUS = 0x8800;
		IP_CAM = 0xC920;
		IP_TV = 0xC924;
		IP_MFC = 0xC928;
		IP_G3D = 0xC92C;
		IP_IMAGE = 0xC930;
		IP_LCD0 = 0xC934;
		IP_LCD1 = 0xC938;
		IP_FSYS = 0xC940;
		IP_GPS = 0xC94C;
		IP_PERIL = 0xC950;
		IP_PERIR = 0xC960;
		IP_DMC = 0x10900;
		IP_CPU = 0x14900;
		SCLKCAM = 0xC820;
		SCLKCPU = 0x14800;
		BLOCK = 0xC970;
		ONCLOCK = 0xFFFFFFFF;
		OFFCLOCK = 0x00000000;
		
		register = new int[18];
		for(int i = 0; i < 18; i++)
			register[i] = 0;
	}
}
/** Automatically generated file. DO NOT MODIFY */
package com.example.clockgatingmonitor;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}